// Copyright (c) 2025 Hanmo Technology Co., Ltd. All rights reserved.

#include "SmartNavigationWidgetBPLibrary.h"
#include "SmartNavigationWidget.h"
#include "UObject/UObjectIterator.h"
#include "Components/Widget.h"

USmartNavigationWidgetBPLibrary::USmartNavigationWidgetBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

void USmartNavigationWidgetBPLibrary::GetAllFocusableWidgets(UObject* WorldContextObject, TArray<UWidget*>& FoundWidgets, UWidget* Parent)
{
	//Prevent possibility of an ever-growing array if user uses this in a loop
	FoundWidgets.Empty();

	if (!WorldContextObject)
	{
		return;
	}

	const UWorld* World = WorldContextObject->GetWorld();
	if (!World)
	{
		return;
	}

	for (TObjectIterator<UWidget> Itr; Itr; ++Itr)
	{
		UWidget* LiveWidget = *Itr;

		// Skip any widget that's not in the current world context or that is not a child of the class specified.
		if (LiveWidget->GetWorld() != World)
		{
			continue;
		}

		if (Parent != nullptr && UWidget::FindChildContainingDescendant(Parent, LiveWidget) == nullptr)
		{
			continue;
		}

		TSharedPtr<SWidget> SafeWidget = LiveWidget->GetCachedWidget();
		if (SafeWidget.IsValid())
		{
			if (SafeWidget->SupportsKeyboardFocus())
			{
				FoundWidgets.Add(LiveWidget);
			}
		}
	}
}
