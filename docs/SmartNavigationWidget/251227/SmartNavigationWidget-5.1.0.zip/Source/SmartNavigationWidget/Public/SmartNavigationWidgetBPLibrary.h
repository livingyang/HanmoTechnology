// Copyright Hanmo Technology, Inc. All Rights Reserved.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "SmartNavigationWidgetBPLibrary.generated.h"

UCLASS()
class USmartNavigationWidgetBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_UCLASS_BODY()

	UFUNCTION(BlueprintCallable, BlueprintCosmetic, Category = "Widget", meta = (WorldContext = "WorldContextObject", DynamicOutputParam = "FoundWidgets"))
	static void GetAllFocusableWidgets(UObject* WorldContextObject, TArray<UWidget*>& FoundWidgets, UWidget* Parent);
};
